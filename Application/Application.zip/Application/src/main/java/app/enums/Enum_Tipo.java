package app.enums;


public enum Enum_Tipo {
    EXTRAESCOLAR, COMPLEMENTARIA;
}
