package app.enums;


public enum Enum_Estado {
    SOLICITADA, ACEPTADA, DENEGADA, REALIZADA;
}
