package app.enums;


public enum Enum_Perfil {
    PROFESOR, GRUPO_DIRECTIVO, ADMINISTRADOR, SUPERUSUARIO;
}
