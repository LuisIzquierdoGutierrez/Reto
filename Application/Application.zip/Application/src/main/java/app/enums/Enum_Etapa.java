package app.enums;


public enum Enum_Etapa {
    ESO, BACHILLERATO, FPB, FPGM, FPGS, FPCE;
}
